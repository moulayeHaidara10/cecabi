export const options = oceanwpLocalize;
